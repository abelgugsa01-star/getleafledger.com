# Your first month with LeafLedger

Practice with fictional records before using your own. Nothing in this sample establishes the facts of a real
business. Do not submit the sample drafts.

## 1. Open the practice workspace

Extract this ZIP to a folder on your computer, for example `C:\LeafLedger-Practice`. Start LeafLedger and,
if it asks for a folder, point it at the extracted `LeafLedger-Practice` folder (or run
`LeafLedger.exe C:\LeafLedger-Practice\LeafLedger-Practice`). The overview shows *Setup complete*.

## 2. Look at the setup

Open **Setup**. Two fictional companies, one manufacturer permit and one importer permit, one product each
(small cigarettes), the source file layouts, the account mapping and the evidence files for August 2026 are
already entered. Read each card; this is what you will enter once for your own business.

## 3. Add the month's source files

Open **Monthly cycle**, type `2026-08`, click **Load month**. Add `sources/manufacturer_month.csv` with the
*manufacturer* profile and `sources/importer_month.csv` with the *importer* profile (both are in this ZIP).

## 4. Prepare the month

Click **Prepare this month**. LeafLedger reads every row, checks every captured rule and renders the drafts.
The engine status should be **READY TO FILE** and the monthly preparation **REVIEW REQUIRED**.

## 5. Read the review

Open **Review & export**. Two kinds of item stay open on purpose: *MISSING_OFFICIAL_SUPPORT* (the official copy
of a form is not among the evidence) and *OFFICIAL_RENDERING_UNVALIDATED* (drafts are watermarked). Scroll to
the draft lines: line 7.d opening stock 100,000 sticks; every number names the source rows behind it. Open a
PDF. Nothing here is submitted.

## 6. Practice a missing fact

Back in **Setup**, remove the mapping for `taxable_removal` under Account mapping, save, and prepare
2026-08 again with the correction reason "practice". The month now stops with an unknown account instead of
guessing. Add the mapping back, save, and prepare once more; the result returns.

## 7. Keep and recover your work

**History** lists every preparation; corrections supersede, nothing is deleted. On the overview, create an
encrypted backup with a passphrase you choose; the passphrase is never stored.

## Quick checklist

- [ ] Practice workspace opened, setup complete
- [ ] Two source files added for 2026-08
- [ ] Month prepared: engine READY TO FILE
- [ ] Draft lines read; a PDF opened
- [ ] Missing-fact exercise done and mapping restored
- [ ] Backup created
